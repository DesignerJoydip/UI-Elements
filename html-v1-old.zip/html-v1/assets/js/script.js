$(document).ready(function() {
    'use strict';

    /* header search popup open */
    $(".header-search-btn").click(function(){
        $(".hdr-search-popup-area").addClass("active");
    });
    $(".search-close-btn").click(function(){
        $(".hdr-search-popup-area").removeClass("active");
        $(".hdr-search-popup-area input[type='text']").val('');
    });
    /* header search popup closed */
    
});

/*$(window).on('load', function() {
    $('.preloader').fadeOut('slow', function () { $(this).remove(); });
});*/






